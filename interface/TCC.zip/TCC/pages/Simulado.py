import streamlit as st
from pathlib import Path

# ================= CONFIGURAÇÃO DA PÁGINA =================
st.set_page_config(page_title="Simulado", layout="wide")

# ================= CSS =================
st.markdown("""
    <style>
         /* ===== MENU SUPERIOR ===== */
    .menu {
        display: flex;
        justify-content: center;
        gap: 40px;
        margin-bottom: 40px;
        font-size: 20px;
        font-weight: 600;
    }
    .menu a {
        text-decoration: none;
        color: #bbb;
        transition: color 0.2s;
    }
    .menu a:hover {
        color: #fff;
    }
    .menu a.active {
        color: #fff;
        font-weight: 700;
        border-bottom: 2px solid #1e90ff;
        padding-bottom: 4px;
    }
               
        .main {
            background-color: #f5f5f5;
        }
        .video-container {
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 0 8px rgba(0,0,0,0.2);
        }
        .info-box {
            display: flex;
            align-items: center;
            background-color: #b3b3b3;
            border-radius: 6px;
            margin: 4px;
            padding: 4px 8px;
            color: black;
        }
        .info-label {
            background-color: #1e2b3b;
            color: white;
            border-radius: 4px;
            padding: 2px 6px;
            font-weight: bold;
            margin-right: 6px;
            font-size: 0.9rem;
        }
        .result-box {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background-color: #b3b3b3;
            border-radius: 6px;
            padding: 4px 10px;
            margin: 4px;
            color: black;
        }
        .result-label {
            background-color: #1e2b3b;
            color: white;
            border-radius: 4px;
            padding: 4px 8px;
            font-weight: bold;
        }
        .map-preview {
            position: relative;
            text-align: center;
            color: white;
            font-weight: bold;
        }
        .map-preview img {
            border-radius: 8px;
            width: 100%;
            opacity: 0.85;
        }
        .map-preview-text {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 1.1rem;
            background-color: rgba(0,0,0,0.5);
            padding: 6px 10px;
            border-radius: 6px;
        }
    </style>
""", unsafe_allow_html=True)

st.markdown("""
<div class="menu">
    <a href="../app" >Menu</a>
    <a href="./Mapas">Mapas</a>
    <a href="./Parâmetros">Parâmetros</a>
    <a href="./Resultados" class="active">Resultados</a>
    <a href="./Documentação">Documentação</a>
</div>
""", unsafe_allow_html=True)

# ================= DADOS DE EXEMPLO =================
mapa_img = Path("mapas/3.png")  # Altere conforme o mapa real
video_file = Path("videos/simulacao.mp4")  # Arquivo de vídeo de exemplo

dados = {
    "Nome": "abc",
    "Parametrização": "abc",
    "Algoritmo": "abc",
    "ID": "123",
}

resultados = {
    "Resultado A": "123",
    "Resultado B": "123",
    "Resultado C": "123",
    "Resultado D": "123",
    "Geral": "123"
}

# ================= LAYOUT =================
col1, col2 = st.columns([4, 1])

with col1:
    st.markdown('<div class="video-container">', unsafe_allow_html=True)
    if video_file.exists():
        st.video(str(video_file))
    else:
        st.image(str(mapa_img), use_container_width=True)
    st.markdown('</div>', unsafe_allow_html=True)

with col2:
    if mapa_img.exists():
        st.markdown('<div class="map-preview">', unsafe_allow_html=True)
        st.image(str(mapa_img))
        st.markdown('</div>', unsafe_allow_html=True)
    for nome, valor in resultados.items():
        st.markdown(f"""
            <div class="result-box">
                <div class="result-label">{nome}</div>
                <div>{valor}</div>
            </div>
        """, unsafe_allow_html=True)

# ================= INFORMAÇÕES INFERIORES =================
st.write("")
st.markdown("### ")

info_cols = st.columns([2, 2, 2, 1])
labels = list(dados.keys())
values = list(dados.values())

for i in range(len(labels)):
    with info_cols[i]:
        st.markdown(f"""
            <div class="info-box">
                <div class="info-label">{labels[i]}:</div>
                <div>{values[i]}</div>
            </div>
        """, unsafe_allow_html=True)
